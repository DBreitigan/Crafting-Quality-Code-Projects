import static org.junit.Assert.*;

import org.junit.Test;


public class TestActions 
{

	@Test
	public void testValueIsDigitAction() 
	{
		Action digit = new ValueIsDigitAction();
		
	}

}
