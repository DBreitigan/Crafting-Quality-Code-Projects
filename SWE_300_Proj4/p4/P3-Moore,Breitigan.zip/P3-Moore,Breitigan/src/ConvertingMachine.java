import exceptions.EnumIndexException;

/**
 * A finite state machine that parses a string containing a real number. Will
 * throw NumberFormatExcaption if the string doesn't not contain a legal
 * representation of a real number. Note: we are not dealing with scientific
 * notation
 *
 * @author Merlin
 *
 */
public class ConvertingMachine
{

	private final Edge[] machine =
	{
			new Edge(State.START, new DigitInputVerifier(),
					new ValueIsDigitAction(), State.INTEGER),
			new Edge(State.START, new MinusInputVerifier(), new NegateAction(),
					State.INTEGER),
			new Edge(State.START, new PlusInputVerifier(), new NoAction(),
					State.INTEGER),
			new Edge(State.START, new PeriodInputVerifier(),
					new StartFraction(), State.DECIMAL),
			new Edge(State.INTEGER, new DigitInputVerifier(),
					new ContinuingIntegerAction(), State.INTEGER),
			new Edge(State.INTEGER, new PeriodInputVerifier(),
					new StartFraction(), State.DECIMAL),
			new Edge(State.DECIMAL, new DigitInputVerifier(),
					new ContinuingFractionAction(), State.DECIMAL)
	};

	public double parse(String text)
	{
		
	}

	//this is where i started having trouble. Not really sure how to go about this.
	private Edge searchForEdge(State currentState, char ch)
	{
		InputVerifier verifier;
		for(int i = 0; i < machine.length; i++)
		{
			verifier = machine[i].getInputVerifier();
			if((verifier.meetsCriteria(ch))&&(currentState == machine[i].getCurrentState()))
			{
				return machine[i];
			}
		}
		return null;
		
	}

	private class Edge
	{
		State currentState;
		InputVerifier inputVerifier;
		Action action;
		State nextState;

		public Edge(State currentState, InputVerifier inputVerifier,
				Action action, State nextState)
		{
			this.currentState = currentState;
			this.inputVerifier = inputVerifier;
			this.action = action;
			this.nextState = nextState;
		}

		public State getCurrentState()
		{
			return currentState;
		}
		
		public InputVerifier getInputVerifier()
		{
			return inputVerifier;
		}
	}

	private enum State
	{
		START, INTEGER, DECIMAL, END;
	}

	public State getState(int i) throws EnumIndexException
	{
		if(i == 0)
			return State.START;
		if(i == 1)
			return State.INTEGER;
		if(i == 2)
			return State.DECIMAL;
		if(i == 3)
			return State.END;
		else
			throw new EnumIndexException();
	}
}
