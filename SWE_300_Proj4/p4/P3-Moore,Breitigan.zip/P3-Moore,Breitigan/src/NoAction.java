
public class NoAction implements Action
{
	public NoAction()
	{
		
	}
	
	public InterimResult execute(InterimResult x, char c)
	{
		return x;
	}
}
