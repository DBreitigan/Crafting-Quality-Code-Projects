
public interface Action
{
	public InterimResult execute(InterimResult x, char c);
}
